angular.module('customerInteractionsApp')
    .controller('InsightDetailsCtrl',["$window","$scope","$rootScope", "$stateParams","$timeout", "$window","insightService", InsightDetailsCtrl]);

function InsightDetailsCtrl($window,$scope,$rootScope,$stateParams, $timeout,$window, insightService ) {
    this.$scope = $scope;
    this.$window = $window;
    this.$rootScope = $rootScope;
    this.$stateParams = $stateParams;
    this.$timeout = $timeout;
    this.$window = $window;
    this.insightService = insightService;
    this.parentState = "member.insightview";
    this.loaded = false;
    var self = this;
    this.init();

    this.insightComments = [];
}

InsightDetailsCtrl.prototype = {
    init:function(){
        var self= this;
        self.insightService.currentComments = [];
        self.getInsightData();

    },
    getInsightData: function(){
        var self = this;
        self.enableWidgets = true;
        self.$rootScope.$broadcast('highlight-link', this.parentState);
        var store = self.$stateParams.storeId;
        self.insightService.getCurrentComments(store)
            .then(function() {
                self.insightComments = self.insightService.currentComments;

                if (self.insightComments.length === 0) {

                    self.loaded = true;
                }

                self.insightComments.reverse();
                self.insightService.currentComments = [];
            })
    },
    postComment: function() {
        var self = this;
        var currentTime = new Date();
        var month, day, year;
        self.loaded = false;
        currentTime = JSON.stringify(currentTime).split("").splice(1,10);

        year = currentTime.slice(0,4);
        month = currentTime.slice(5,7);
        day = currentTime.slice(8,10);

        currentTime = [month.join(''),day.join(''),year.join('')].join('-');

        var obj = {
            store: self.$stateParams.storeId,
            properties: {
                store : self.$scope.cmtName,
                ldap : self.authService.ldapDetails.id,
                email : self.authService.ldapDetails.email,
                date: currentTime,
                storeNbr: self.$stateParams.storeId
            }
        }

        self.insightService.addComment(obj)
            .then(function() {
                self.insightComments.push(obj.properties);
                self.insightComments.reverse();
            })

    }
}
