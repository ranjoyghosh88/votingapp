angular.module("customerInteractionsApp")
			.controller('CustomerSummaryController',
				[
					'$scope',
					'$http',
					'CustomerDetails',
          '$routeParams',
					'InputFileDetails',
					CustomerSummaryController
				]
			 )
			 .directive('fileModel', ['$parse', function ($parse) {
            return {
               restrict: 'A',
               link: function(scope, element, attrs) {
                  var model = $parse(attrs.fileModel);
                  var modelSetter = model.assign;

                  element.bind('change', function(){
                     scope.$apply(function(){
                        modelSetter(scope, element[0].files[0]);
                     });
                  });
               }
            };
         }]);

		function CustomerSummaryController($scope, $http, CustomerDetails,$routeParams, InputFileDetails) {
		   	this.$scope = $scope;
				this.$http = $http;
        this.CustomerDetails = CustomerDetails;
        this.$routeParams = $routeParams;
				this.loading = true;
				this.InputFileDetails = InputFileDetails;
				this.voteList = '';
				this.getCustomerSummary();
		};

		CustomerSummaryController.prototype = {

				getCustomerSummary:function() {
						var self = this;
						var w = 300,                        //width
				    h = 300,                            //height
				    r = 100,                            //radius
				    color = d3.scale.category20c();     //builtin range of colors

				     data = [{
				"_id": {
				"$oid": "5b1fdfcee7179a589280331a"
				},
				"name": "KA Election",
				"comment": "test",
				"voted": 122,
				"created_at": "2018-06-12"
				},{
				"_id": {
				"$oid": "5b1fdfcee7179a589280331b"
				},
				"name": "WB Election",
				"comment": "test",
				"voted": 10,
				"created_at": "2018-06-12"
				},{
				"_id": {
				"$oid": "5b1fdfcee7179a589280331b"
				},
				"name": "BH Election",
				"comment": "test",
				"voted": 11,
				"created_at": "2018-06-12"
				},{
				"_id": {
				"$oid": "5b1fdfcee7179a589280331b"
				},
				"name": "UK Election",
				"comment": "test",
				"voted": 1,
				"created_at": "2018-06-12"
				},{
				"_id": {
				"$oid": "5b1fdfcee7179a589280331b"
				},
				"name": "MP Election",
				"comment": "test",
				"voted": 15,
				"created_at": "2018-06-12"
				},{
				"_id": {
				"$oid": "5b1fdfcee7179a589280331b"
				},
				"name": "UP Election",
				"comment": "test",
				"voted": 19,
				"created_at": "2018-06-12"
				},{
				"_id": {
				"$oid": "5b1fdfcee7179a589280331b"
				},
				"name": "TN Election",
				"comment": "test",
				"voted": 12,
				"created_at": "2018-06-12"
				},{
				"_id": {
				"$oid": "5b1fdfcee7179a589280331b"
				},
				"name": "KL Election",
				"comment": "test",
				"voted": 12,
				"created_at": "2018-06-12"
				}];
				    var vis = d3.select("body")
				        .append("svg:svg")              //create the SVG element inside the <body>
				        .data([data])                   //associate our data with the document
				            .attr("width", w)           //set the width and height of our visualization (these will be attributes of the <svg> tag
				            .attr("height", h)
				        .append("svg:g")                //make a group to hold our pie chart
				            .attr("transform", "translate(" + r + "," + r + ")")    //move the center of the pie chart from 0, 0 to radius, radius

				    var arc = d3.svg.arc()              //this will create <path> elements for us using arc data
				        .outerRadius(r);

				    var pie = d3.layout.pie()           //this will create arc data for us given a list of voteds
				        .voted(function(d) { return d.voted; });    //we must tell it out to access the voted of each element in our data array

				    var arcs = vis.selectAll("g.slice")     //this selects all <g> elements with class slice (there aren't any yet)
				        .data(pie)                          //associate the generated pie data (an array of arcs, each having startAngle, endAngle and voted properties)
				        .enter()                            //this will create <g> elements for every "extra" data element that should be associated with a selection. The result is creating a <g> for every object in the data array
				            .append("svg:g")                //create a group to hold each slice (we will have a <path> and a <text> element associated with each slice)
				                .attr("class", "slice");    //allow us to style things in the slices (like text)

				        arcs.append("svg:path")
				                .attr("fill", function(d, i) { return color(i); } ) //set the color for each slice to be chosen from the color function defined above
				                .attr("d", arc);                                    //this creates the actual SVG path using the associated data (pie) with the arc drawing function

				        arcs.append("svg:text")                                     //add a name to each slice
				                .attr("transform", function(d) {                    //set the name's origin to the center of the arc
				                //we have to make sure to set these before calling arc.centroid
				                d.innerRadius = 0;
				                d.outerRadius = r;
				                return "translate(" + arc.centroid(d) + ")";        //this gives us a pair of coordinates like [50, 50]
				            })
				            .attr("text-anchor", "middle")                          //center the text on it's origin
				            .text(function(d, i) { return data[i].name; });        //get the name from our original data array

		    }
		};
