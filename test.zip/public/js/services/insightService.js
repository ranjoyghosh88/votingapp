(function () {
    'use strict';
    angular
        .module('customerInteractionsApp')
        .service('insightService', [
            '$q',
            '$http',
            'sessionStorage',
            'appConfig',
            '$analytics',
            insightService
        ])


    function insightService(
        $q,
        $http,
        sessionStorage,
        appConfig,
        $analytics
    ) {
        this.$q = $q;
        this.$http = $http;
        this.sessionStorage = sessionStorage;
        this.appConfig = appConfig;
        this.$analytics = $analytics;
        this.ldapDetails = {};
        this.currentComments = [];

    }

    insightService.prototype = {

        getCurrentComments: function(store) {
            var self = this;
            return this.$http({
                method: 'post',
                url: 'api/comments',
                data: {
                    id: store
                }
            }).then(function(result) {
                result.data.forEach(function(index) {
                    self.currentComments.push(index.properties);
                })
                return self.currentComments;
            });
        },
        addComment: function(store){
            var self = this;
            return this.$http({
                method: 'post',
                url: 'api/addComment',
                data: store
            }).then(function(result) {
                //console.log(result);
            });
        }
    };

})();
