module.exports = {

     localUrl: 'mongodb://ranjoy.ghosh88:Ranjoy123@@@ds255930.mlab.com:55930/storedata'
};
