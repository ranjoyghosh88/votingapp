var mongoose = require('mongoose');
var Schema = mongoose.Schema;
module.exports = mongoose.model("customerDetails", {
    _id: {
        type: Object,
        default: {}
    },
    "name": {
        type: String,
        default: ''
    },
    "comment": {
        type: String,
        default: ''
    },
    "voted": {
        type: String,
        default: ''
    },
    created_at: {
        type: Date
    }

}, "vote");
