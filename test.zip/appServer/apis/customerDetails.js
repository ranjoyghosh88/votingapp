var customer = require('../models/customerDetails');
var q = require('q');
// var loadash = require('lodash');

function getCustomerDetails(res, queryParams) {
      customer.find({},function (err, details) {
          // if there is an error retrieving, send the error. nothing after res.send(err) will execute
          if (err) {
              res.send(err);
          }
          res.json(details); // return all details in JSON format
      }).sort({ "id": -1 }).skip(startCo).limit( 100 );

};
function getCustomersById(pnrId, res) {
    customer.find({"PNR": pnrId},function (err, details) {
        // if there is an error retrieving, send the error. nothing after res.send(err) will execute
        if (err) {
            res.send(err);
        }

        res.json(details); // return all repo in JSON format
    });

};
function getVotingList(res) {
    customer.find({},function (err, details) {
        // if there is an error retrieving, send the error. nothing after res.send(err) will execute
        if (err) {
            res.send(err);
        }

        res.json(details); // return all repo in JSON format
    });

};
function saveCustomers(data,data1,res){
  console.log(data,"data")
  console.log(data1,"data1")
  customer.insert(data,data1,function (err, details) {
      // if there is an error retrieving, send the error. nothing after res.send(err) will execute
      if (err) {
          res.send(err);
      }

      res.json(details); // return all repo in JSON format
  });
};

// module.exports = function (app, q, loadash) {
module.exports = function (app) {

    // api ---------------------------------------------------------------------
    app.get('/api/customer/:pnrId', function (req, res) {

        getCustomersById( req.params.pnrId, res);
    });
    app.get('/api/votes', function (req, res) {

        // getVotingList(res);
        // customer.find({},function (err, details) {
            // if there is an error retrieving, send the error. nothing after res.send(err) will execute
            // if (err) {
            //     res.send(err);
            // }
            var details = [{
    "_id": {
        "$oid": "5b1fdfcee7179a589280331a"
    },
    "name": "KA Election",
    "comment": "test",
    "voted": 122,
    "created_at": "2018-06-12"
},{
    "_id": {
        "$oid": "5b1fdfcee7179a589280331b"
    },
    "name": "WB Election",
    "comment": "test",
    "voted": 10,
    "created_at": "2018-06-12"
},{
    "_id": {
        "$oid": "5b1fdfcee7179a589280331b"
    },
    "name": "BH Election",
    "comment": "test",
    "voted": 11,
    "created_at": "2018-06-12"
},{
    "_id": {
        "$oid": "5b1fdfcee7179a589280331b"
    },
    "name": "UK Election",
    "comment": "test",
    "voted": 1,
    "created_at": "2018-06-12"
},{
    "_id": {
        "$oid": "5b1fdfcee7179a589280331b"
    },
    "name": "MP Election",
    "comment": "test",
    "voted": 15,
    "created_at": "2018-06-12"
},{
    "_id": {
        "$oid": "5b1fdfcee7179a589280331b"
    },
    "name": "UP Election",
    "comment": "test",
    "voted": 19,
    "created_at": "2018-06-12"
},{
    "_id": {
        "$oid": "5b1fdfcee7179a589280331b"
    },
    "name": "TN Election",
    "comment": "test",
    "voted": 12,
    "created_at": "2018-06-12"
},{
    "_id": {
        "$oid": "5b1fdfcee7179a589280331b"
    },
    "name": "KL Election",
    "comment": "test",
    "voted": 12,
    "created_at": "2018-06-12"
}];

            res.json(details); // return all repo in JSON format
        // });
    });


    app.get("/api/addComment/:name/:cmnt", function(req, res, next) {
    // var appUser = appUserHelper(req);
    console.log(req.params.name,req.params.cmnt,"datasss")
        saveCustomers( req.params.name,req.params.cmnt, res);
        // user = appUser.userDetails.userId;

    });

    // app.delete('/api/customer/:pnrId', function (req, res) {
    //     // use mongoose to get all repos in the database

    // });


    // app.get('*', function (req, res) {
    //     res.sendFile(__dirname + '/public/index.html'); // load the single view file (angular will handle the page changes on the front-end)
    // });
};
